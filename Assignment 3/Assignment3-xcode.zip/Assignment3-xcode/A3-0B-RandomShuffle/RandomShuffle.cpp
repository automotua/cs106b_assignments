/* File: RandomShuffle.cpp
 *
 * A program that uses recursion to randomly scramble the contents of
 * a string.
 */
#include <iostream>
#include <string>
#include "random.h"
#include "console.h"
using namespace std;

/* Function: randomShuffle(string input);
 * Usage: cout << randomShuffle("keith") << endl; // Might get htiek
 * =================================================================
 * Returns a random permutation of the given string.
 */
string randomShuffle(string input);

int main() {
	// TODO: Add your testing code here!
	return 0;
}

string randomShuffle(string input) {
	// TODO: Implement this!
}

