/*************************************************************
 * File: pqueue-linkedlist.cpp
 *
 * Implementation file for the LinkedListPriorityQueue
 * class.
 */
 
#include "pqueue-linkedlist.h"
#include "error.h"

LinkedListPriorityQueue::LinkedListPriorityQueue() {
	// TODO: Fill this in!
}

LinkedListPriorityQueue::~LinkedListPriorityQueue() {
	// TODO: Fill this in!
}

int LinkedListPriorityQueue::size() {
	// TODO: Fill this in!
	
	return 0;
}

bool LinkedListPriorityQueue::isEmpty() {
	// TODO: Fill this in!
	
	return true;
}

void LinkedListPriorityQueue::enqueue(string value) {
	// TODO: Fill this in!
}

string LinkedListPriorityQueue::peek() {
	// TODO: Fill this in!
	
	return "";
}

string LinkedListPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

