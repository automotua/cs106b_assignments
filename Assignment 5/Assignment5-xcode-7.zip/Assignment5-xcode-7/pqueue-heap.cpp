/*************************************************************
 * File: pqueue-heap.cpp
 *
 * Implementation file for the HeapPriorityQueue
 * class.
 */
 
#include "pqueue-heap.h"
#include "error.h"

HeapPriorityQueue::HeapPriorityQueue() {
	// TODO: Fill this in!
}

HeapPriorityQueue::~HeapPriorityQueue() {
	// TODO: Fill this in!
}

int HeapPriorityQueue::size() {
	// TODO: Fill this in!
	
	return 0;
}

bool HeapPriorityQueue::isEmpty() {
	// TODO: Fill this in!
	
	return true;
}

void HeapPriorityQueue::enqueue(string value) {
	// TODO: Fill this in!
}

string HeapPriorityQueue::peek() {
	// TODO: Fill this in!
	
	return "";
}

string HeapPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

