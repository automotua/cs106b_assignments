/*************************************************************
 * File: pqueue-extra.cpp
 *
 * Implementation file for the ExtraPriorityQueue class.  You
 * do not need to implement this class, but we're happy to
 * give you extra credit if you do!
 */
 
#include "pqueue-extra.h"
#include "error.h"

ExtraPriorityQueue::ExtraPriorityQueue() {
	// TODO: Fill this in!
}

ExtraPriorityQueue::~ExtraPriorityQueue() {
	// TODO: Fill this in!
}

int ExtraPriorityQueue::size() {
	// TODO: Fill this in!
	
	return 0;
}

bool ExtraPriorityQueue::isEmpty() {
	// TODO: Fill this in!
	
	return true;
}

void ExtraPriorityQueue::enqueue(string value) {
	// TODO: Fill this in!
}

string ExtraPriorityQueue::peek() {
	// TODO: Fill this in!
	
	return "";
}

string ExtraPriorityQueue::dequeueMin() {
	// TODO: Fill this in!
	
	return "";
}

